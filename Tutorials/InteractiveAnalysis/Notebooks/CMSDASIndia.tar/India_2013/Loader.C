#include <vector>
#include <map>
#include <string>
#include "Track.h"
#include "GenParticle.h"
#ifdef __CINT__
#pragma link C++ class Track+;
#pragma link C++ class std::vector<Track>+;
#pragma link C++ class std::map<std::string, std::vector<Track> >+;
#pragma link C++ class GenParticle+;
#pragma link C++ class std::vector<GenParticle>+;
#endif
